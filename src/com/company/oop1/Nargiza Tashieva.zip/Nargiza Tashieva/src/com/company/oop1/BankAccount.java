package com.company.oop1;

public class BankAccount {
    public int ID;
    public int balance;
}
